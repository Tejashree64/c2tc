package com.tnsif.pm.certificate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PlacementMCertificateApplicationTests {

	@Test
	void contextLoads() {
	}

}
